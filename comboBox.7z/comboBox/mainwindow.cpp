#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_VI_clicked()
{

    QMessageBox::information(this,"item",ui->caixaItens->currentText());

}


void MainWindow::on_add_clicked()
{


    ui->ADDI->addItem(ui->txt->text());
}

