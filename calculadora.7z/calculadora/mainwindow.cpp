#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_mais_clicked()
{

    QString v1,v2;
    v1=ui->txtn1->text();
    v2=ui->txtn2->text();
    if(v1==""){
        QMessageBox::information(this,"atenção", "você precisa digitar o primeiro número");
    }else if(v2==""){
        QMessageBox::information(this,"atenção", "você precisa digitar o segundo número");
    }else{
        double n1,n2, resultado;
        n1=QString(v1).toDouble();
        n2=QString(v2).toDouble();
        resultado=n1+n2;
        ui->txtre->setText(QString::number(resultado));
    }

}


void MainWindow::on_menos_clicked()
{

    QString v1,v2;
    v1=ui->txtn1->text();
    v2=ui->txtn2->text();
    if(v1==""){
        QMessageBox::information(this,"atenção", "você precisa digitar o primeiro número");
    }else if(v2==""){
        QMessageBox::information(this,"atenção", "você precisa digitar o segundo número");
    }else{
        double n1,n2, resultado;
        n1=QString(v1).toDouble();
        n2=QString(v2).toDouble();
        resultado=n1-n2;
        ui->txtre->setText(QString::number(resultado));
    }

}



void MainWindow::on_vezes_clicked()
{
    QString v1,v2;
    v1=ui->txtn1->text();
    v2=ui->txtn2->text();
    if(v1==""){
        QMessageBox::information(this,"atenção", "você precisa digitar o primeiro número");
    }else if(v2==""){
        QMessageBox::information(this,"atenção", "você precisa digitar o segundo número");
    }else{
        double n1,n2, resultado;
        n1=QString(v1).toDouble();
        n2=QString(v2).toDouble();
        resultado=n1*n2;
        ui->txtre->setText(QString::number(resultado));
    }

}



void MainWindow::on_divisao_clicked()
{
    QString v1,v2;
    v1=ui->txtn1->text();
    v2=ui->txtn2->text();
    if(v1==""){
        QMessageBox::information(this,"atenção", "você precisa digitar o primeiro número");
    }else if(v2==""){
        QMessageBox::information(this,"atenção", "você precisa digitar o segundo número");
    }else{
        double n1,n2, resultado;
        n1=QString(v1).toDouble();
        n2=QString(v2).toDouble();
        resultado=n1/n2;
        ui->txtre->setText(QString::number(resultado));
    }

}


