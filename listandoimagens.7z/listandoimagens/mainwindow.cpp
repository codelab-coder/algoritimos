#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QPixmap imagem(":/imagens/imagenscarros/lamborghini-huracan-Alexander-Migl-wikimedia-commons.jpg");
    ui->label_4->setPixmap(imagem);
}

MainWindow::~MainWindow()
{
    delete ui;
}
