import sqlite3
from tkinter import Tk, Label, Entry, Button, W

# Nome do banco de dados
DB_NOME = "Projeto_Compras.db"


# Conexão com o banco de dados
def conectar_banco():
    try:
        conexao = sqlite3.connect(DB_NOME)
        return conexao
    except Exception as e:
        print(f"Erro ao conectar ao banco de dados: {e}")
        return None


# Função para verificar se há produtos na tabela
def verifica_login():
    conexao = conectar_banco()
    if conexao:
        cursor = conexao.cursor()
        try:
            cursor.execute("SELECT COUNT(*) FROM produtos")  # Verifica se a tabela contém itens
            if cursor.fetchone()[0] > 0:
                print("Login bem-sucedido!")
                janela_principal.destroy()
                abrir_interface_principal()
            else:
                print("Nenhum produto encontrado! Verifique o banco de dados.")
        except sqlite3.Error as e:
            print(f"Erro ao acessar os dados: {e}")
        finally:
            conexao.close()
    else:
        print("Falha ao conectar ao banco de dados.")


# Função para listar os produtos
def listar_produtos():
    conexao = conectar_banco()
    if conexao:
        cursor = conexao.cursor()
        cursor.execute("SELECT * FROM produtos")
        produtos = cursor.fetchall()
        for produto in produtos:
            print(produto)
        conexao.close()


# Função para calcular a soma dos preços
def calcula_soma_preco():
    conexao = conectar_banco()
    if conexao:
        cursor = conexao.cursor()
        cursor.execute("SELECT SUM(preco) FROM produtos")
        total = cursor.fetchone()[0]

        if total is None:
            total = 0.0  # Define como 0 caso não haja produtos

        soma_label.config(text=f"Total: R$ {total:.2f}")
        conexao.close()


# Interface principal após o login
def abrir_interface_principal():
    global soma_label

    janela = Tk()
    janela.title("Gestão de Produtos")

    soma_label = Label(janela, text="Total: R$ 0.00", font="Arial 16")
    soma_label.grid(row=0, column=0, columnspan=2, pady=10)

    botao_atualizar_soma = Button(janela, text="Atualizar Total", command=calcula_soma_preco, font="Arial 16")
    botao_atualizar_soma.grid(row=1, column=0, columnspan=2, sticky="NSEW", pady=10, padx=10)

    # Exibir soma inicial
    calcula_soma_preco()

    janela.mainloop()


# Criando a tela de login baseada no banco de dados
janela_principal = Tk()
janela_principal.title("Login")
janela_principal.configure(background="#F5F5F5")

largura_login = 400
altura_login = 200
largura_tela = janela_principal.winfo_screenwidth()
altura_tela = janela_principal.winfo_screenheight()
pos_x = (largura_tela // 2) - (largura_login // 2)
pos_y = (altura_tela // 2) - (altura_login // 2)
janela_principal.geometry(f"{largura_login}x{altura_login}+{pos_x}+{pos_y}")

Label(janela_principal, text="Clique para conectar ao banco de dados:", font="Arial 14", background="#F5F5F5").grid(
    row=0, column=0, columnspan=2, padx=10, pady=10)

botao_login = Button(janela_principal, text="Login", command=verifica_login, font="Arial 16")
botao_login.grid(row=1, column=0, columnspan=2, sticky="NSEW", pady=10, padx=10)

botao_sair = Button(janela_principal, text="Sair", command=janela_principal.destroy, font="Arial 16")
botao_sair.grid(row=2, column=0, columnspan=2, sticky="NSEW", pady=10, padx=10)

for i in range(3):
    janela_principal.grid_rowconfigure(i, weight=1)
for i in range(2):
    janela_principal.grid_columnconfigure(i, weight=1)

janela_principal.mainloop()
