#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"contatos.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QStringList titulos;
    ui->tableWidget->setColumnCount(3);
    titulos<<"nome"<<"telefone"<<"email";
    ui->tableWidget->setHorizontalHeaderLabels(titulos);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_novo_clicked()
{
    int resultado;
    QString nome,telefone,email;
    contatos dadoscontato;
    dadoscontato.exec();
    if(resultado=QDialog::Rejected){
        return;
    }else{
        nome= dadoscontato.nomecontado();
        telefone= dadoscontato.telefonecontado();
        email= dadoscontato.emailcontado();
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-1,0, new QTableWidgetItem(nome));
        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-2,1, new QTableWidgetItem(telefone));

        ui->tableWidget->insertRow(ui->tableWidget->rowCount());
        ui->tableWidget->setItem(ui->tableWidget->rowCount()-3,2, new QTableWidgetItem(email));


    }


}

