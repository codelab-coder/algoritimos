#include "contatos.h"
#include "ui_contatos.h"

contatos::contatos(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::contatos)
{
    ui->setupUi(this);
}

contatos::~contatos()
{
    delete ui;

}

QString contatos::nomecontado()const{
    return ui->nome->text();
}
    QString contatos::telefonecontado()const{
        return ui->numero->text();
    }
        QString contatos::emailcontado()const{
            return ui->email->text();
        }






        void contatos::on_buttonBox_accepted()
        {
         accept();
}


        void contatos::on_buttonBox_rejected()
        {
            rejected();
        }


