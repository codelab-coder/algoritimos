#ifndef CONTATOS_H
#define CONTATOS_H

#include <QDialog>

namespace Ui {
class contatos;
}

class contatos : public QDialog
{
    Q_OBJECT

public:
    explicit contatos(QWidget *parent = nullptr);
    ~contatos();
    QString nomecontado()const;
    QString telefonecontado()const;
    QString emailcontado()const;

private slots:
    void on_buttonBox_accepted();

    void on_buttonBox_rejected();

private:
    Ui::contatos *ui;
};

#endif // CONTATOS_H
