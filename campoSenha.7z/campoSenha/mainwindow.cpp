#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_log_clicked()
{

    QString nome= ui->txtU->text();
    QString senha=ui->txtS->text();

    if(nome=="ana paula"&& senha=="aluno"){
        QMessageBox::information(this,"tela login", "usuário logado com sucesso");


    }else{

        QMessageBox::information(this,"tela login", "usuário ou senha inválidos");

    }

}

