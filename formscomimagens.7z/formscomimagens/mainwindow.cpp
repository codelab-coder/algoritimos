#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QPixmap caminhoimagem("C:/Users/dinha/Downloads/lamborghini-huracan-Alexander-Migl-wikimedia-commons.jpg");
    ui->label_2->setPixmap(caminhoimagem.scaled(100,100, Qt::KeepAspectRatio));

}

MainWindow::~MainWindow()
{
    delete ui;
}
