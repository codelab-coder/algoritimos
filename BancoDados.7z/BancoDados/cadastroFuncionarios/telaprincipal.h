#ifndef TELAPRINCIPAL_H
#define TELAPRINCIPAL_H

#include <QDialog>

namespace Ui {
class telaprincipal;
}

class telaprincipal : public QDialog
{
    Q_OBJECT

public:
    explicit telaprincipal(QWidget *parent = nullptr);
    ~telaprincipal();

private:
    Ui::telaprincipal *ui;
};

#endif // TELAPRINCIPAL_H
