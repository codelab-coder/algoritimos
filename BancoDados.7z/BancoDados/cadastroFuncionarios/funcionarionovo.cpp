#include "funcionarionovo.h"
#include "ui_funcionarionovo.h"

#include <QtSql>
#include <QMessageBox>

funcionarionovo::funcionarionovo(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::funcionarionovo)
{
    ui->setupUi(this);

    // Configuração inicial das máscaras e placeholders
    ui->lineEdit->setInputMask("000.000.000-00");
    ui->lineEdit_6->setInputMask("(99) 99999-9999");
    ui->lineEdit_4->setInputMask("99/99/9999");

    ui->lineEdit_2->setPlaceholderText("digite o nome do funcionário");
    ui->comboBox->setPlaceholderText("selecione o departamento desejado");
    ui->lineEdit_5->setPlaceholderText("digite o e-mail do funcionário");
}

funcionarionovo::~funcionarionovo()
{
    delete ui;
}

void funcionarionovo::on_pushButton_clicked()
{

    QString salariosemvirgula;

    // Coletar os dados
    QString cpf = ui->lineEdit->text();
    QString nome = ui->lineEdit_2->text();
    salariosemvirgula=ui->lineEdit_3->text();
    salariosemvirgula.replace(0,3,"");
    salariosemvirgula.replace(".","");
    salariosemvirgula.replace(",",".");
    QString salario=salariosemvirgula;
    QString departamento = ui->comboBox->currentText();
    QString datanascimento = ui->lineEdit_4->text();
    QString telefone = ui->lineEdit_6->text();
    QString email = ui->lineEdit_5->text();

    // Inserir no banco de dados
    QSqlQuery dados;
    dados.prepare("INSERT INTO Funcionarios (CPF, NomeFuncionario, SalarioFuncionario, DepartamentoFuncionario, DataNascimentoFuncionario, TelefoneFuncionario, EmailFuncionario) "
                  "VALUES (:cpf, :nome, :salario, :departamento, :datanascimento, :telefone, :email)");

    dados.bindValue(":cpf", cpf);
    dados.bindValue(":nome", nome);
    dados.bindValue(":salario", salario);
    dados.bindValue(":departamento", departamento);
    dados.bindValue(":datanascimento", datanascimento);
    dados.bindValue(":telefone", telefone);
    dados.bindValue(":email", email);

    if (dados.exec()) {
        QMessageBox::information(this, "Aviso", "Registro salvo com sucesso!");

        this->close();
    } else {
        QMessageBox::warning(this, "Aviso", "Não foi possível salvar no banco de dados.\nErro: " + dados.lastError().text());
    }
}


void funcionarionovo::on_lineEdit_3_editingFinished()
{

    QString valor;
    auto formato= QLocale("de_DE");
    double value=ui->lineEdit_3->text().toDouble();
    valor=formato.toString(value,'f',2);
    ui->lineEdit_3->setText("R$" +valor);


}

