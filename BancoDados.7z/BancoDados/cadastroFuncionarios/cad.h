#ifndef CAD_H
#define CAD_H

#include <QDialog>

namespace Ui {
class cad;
}

class cad : public QDialog
{
    Q_OBJECT

public:
    explicit cad(QWidget *parent = nullptr);
    ~cad();

private:
    Ui::cad *ui;
};

#endif // CAD_H
