#include "cad.h"
#include "ui_cad.h"

cad::cad(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::cad)
{
    ui->setupUi(this);
}

cad::~cad()
{
    delete ui;
}
