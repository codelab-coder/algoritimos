#include "alterardados.h"
#include "ui_alterardados.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QLocale>
#include <QRegularExpression>

alterardados::alterardados(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::alterardados)
{
    ui->setupUi(this);
    // Configurar máscara monetária no campo de salário
    QLocale locale(QLocale::Portuguese, QLocale::Brazil);
    ui->lineEdit_3->setValidator(new QDoubleValidator(0, 10000000, 2, this));
    ui->lineEdit_3->setText(locale.toCurrencyString(0.00));
}

// Destrutor
alterardados::~alterardados()
{
    delete ui;
}

// Método para preencher os campos com os dados do funcionário
void alterardados::setDados(const QString &id, const QString &cpf, const QString &nome,
                            double salario, const QString &departamento,
                            const QString &nascimento, const QString &telefone,
                            const QString &email)
{
    QLocale locale(QLocale::Portuguese, QLocale::Brazil);
    ui->lineEdit->setText(cpf);
    ui->lineEdit_2->setText(nome);
    ui->lineEdit_3->setText(locale.toCurrencyString(salario));
    ui->comboBox->setCurrentText(departamento);
    ui->lineEdit_4->setText(nascimento);
    ui->telefone->setText(telefone);
    ui->email->setText(email);
    m_id = id;  // Armazenar ID para edição
}

void alterardados::on_pushButton_clicked()
{
    // Obter os dados dos campos
    QString cpf = ui->lineEdit->text();
    QString nome = ui->lineEdit_2->text();
    double salario = ui->lineEdit_3->text().remove(QRegularExpression("[^\\d,.]"))
                         .replace(",", ".")
                         .toDouble();
    QString departamento = ui->comboBox->currentText();
    QString nascimento = ui->lineEdit_4->text();
    QString telefone = ui->telefone->text();
    QString email = ui->email->text();

    // Validar campos obrigatórios
    if (cpf.isEmpty() || nome.isEmpty() || departamento.isEmpty() || nascimento.isEmpty() ||
        telefone.isEmpty() || email.isEmpty()) {
        QMessageBox::warning(this, "Aviso", "Todos os campos são obrigatórios.");
        return;
    }

    QSqlQuery query;
    query.prepare("UPDATE funcionarios SET CPF = ?, NomeFuncionario = ?, SalarioFuncionario = ?, "
                  "DepartamentoFuncionario = ?, DataNascimentoFuncionario = ?, TelefoneFuncionario = ?, "
                  "EmailFuncionario = ? WHERE IDF = ?");
    query.addBindValue(cpf);
    query.addBindValue(nome);
    query.addBindValue(salario);
    query.addBindValue(departamento);
    query.addBindValue(nascimento);
    query.addBindValue(telefone);
    query.addBindValue(email);
    query.addBindValue(m_id);  // ID do funcionário a ser atualizado

    if (query.exec()) {
        QMessageBox::information(this, "Sucesso", "Dados atualizados com sucesso!");
        accept();  // Fecha a janela de edição
    } else {
        QMessageBox::critical(this, "Erro", "Erro ao atualizar os dados: " + query.lastError().text());
    }
}
