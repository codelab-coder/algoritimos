#ifndef ALTERARDADOS_H
#define ALTERARDADOS_H

#include <QDialog>

namespace Ui {
class alterardados;
}

class alterardados : public QDialog
{
    Q_OBJECT

public:
    explicit alterardados(QWidget *parent = nullptr);
    ~alterardados();

    // Função para definir os dados a serem exibidos na tela de alteração
    void setDados(const QString &id, const QString &cpf, const QString &nome, double salario,
                  const QString &departamento, const QString &nascimento, const QString &telefone,
                  const QString &email);

private slots:
    void on_pushButton_clicked();  // Função associada ao clique do botão

private:
    Ui::alterardados *ui;  // Ponteiro para a interface gráfica (UI)
    QString m_id;
};

#endif // ALTERARDADOS_H



