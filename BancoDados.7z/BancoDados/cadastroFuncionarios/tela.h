#ifndef TELA_H
#define TELA_H

#include <QDialog>

namespace Ui {
class tela;
}

class tela : public QDialog
{
    Q_OBJECT

public:
    explicit tela(QWidget *parent = nullptr);
    ~tela();
    void carregardados();  // Manter apenas a função de carregamento de dados

private slots:
    void on_lineEdit_textChanged(const QString &arg1); // Função relacionada a mudança de texto
    void on_pushButton_clicked(); // Função relacionada ao botão 1
    void on_pushButton_2_clicked(); // Função relacionada ao botão 2
    void on_tableWidget_cellDoubleClicked(int row, int column); // Função relacionada à célula da tabela

    void on_pushButton_3_clicked();

private:
    Ui::tela *ui;
};

#endif // TELA_H
