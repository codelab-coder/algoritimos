// mainwindow.cpp

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "tela.h"

#include <QtSql>
#include <QDebug>
#include <QFileInfo>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->TxtSenha->setEchoMode(QLineEdit::Password);
    qputenv("QT_PLUGIN_PATH", "C:/Qt/6.8.0/llvm-mingw_64/plugins/sqldrivers");
    QCoreApplication::addLibraryPath("C:/Qt/6.8.0/llvm-mingw_64/plugins/sqldrivers");
    qDebug() << "Drivers disponíveis:" << QSqlDatabase::drivers();
    qDebug() << "Caminhos das bibliotecas carregadas:" << QCoreApplication::libraryPaths();

    // Inicializa o banco de dados
    bancoDados = QSqlDatabase::addDatabase("QSQLITE");
    if (bancoDados.isValid()) {
        qDebug() << "Driver SQLite carregado com sucesso!";
    } else {
        qDebug() << "Erro ao carregar o driver SQLite";
    }

    QFileInfo checkFile("C:/BancoDados/cadastroFuncionarios/CadastroFuncionarios.db");
    if (checkFile.exists() && checkFile.isFile()) {
        qDebug() << "Arquivo de banco de dados encontrado";
    } else {
        qDebug() << "Arquivo de banco de dados não encontrado!";
    }

    bancoDados.setDatabaseName("C:/BancoDados/cadastroFuncionarios/CadastroFuncionarios.db");
    if (bancoDados.open()) {
        ui->statusbar->showMessage("Banco de dados conectado com sucesso");
    } else {
        ui->statusbar->showMessage("Erro ao conectar ao banco de dados");
    }

    ui->TxtNome->setPlaceholderText("Digite seu nome");
    ui->TxtSenha->setPlaceholderText("Digite sua senha");
}

MainWindow::~MainWindow()
{
    delete ui;
    bancoDados.close();  // Fechar a conexão ao sair
}

void MainWindow::on_Logar_clicked()
{
    QString nomeUsuario = ui->TxtNome->text();
    QString senhaUsuario = ui->TxtSenha->text();

    // Reutilize a instância de banco de dados já criada
    if (bancoDados.isOpen()) {
        QSqlQuery consultarBanco;
        consultarBanco.prepare("SELECT * FROM Login WHERE nome = :nome AND senha = :senha");
        consultarBanco.bindValue(":nome", nomeUsuario);
        consultarBanco.bindValue(":senha", senhaUsuario);

        if (consultarBanco.exec()) {
            int contasEncontradas = 0;
            while (consultarBanco.next()) {
                contasEncontradas++;
            }

            if (contasEncontradas == 1) {
                this->close();
                tela abrirTelaPrincipal;
                abrirTelaPrincipal.setModal(true);
                abrirTelaPrincipal.exec();
            } else {
                QMessageBox::critical(this, "Atenção", "Usuário ou senha inválidos");
            }
        } else {
            qDebug() << "Erro na consulta: " << consultarBanco.lastError().text();
        }
    } else {
        QMessageBox::critical(this, "Alerta", "O banco de dados não está aberto");
    }
}



