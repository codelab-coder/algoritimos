#include "telaprincipal.h"
#include "ui_telaprincipal.h"



telaprincipal::telaprincipal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::telaprincipal) // Alocação do ponteiro para a interface
{
    ui->setupUi(this); // Configuração da interface no QDialog
}

telaprincipal::~telaprincipal()
{
    delete ui; // Liberação da memória alocada para a interface
}






