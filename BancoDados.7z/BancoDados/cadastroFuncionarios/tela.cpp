#include "tela.h"
#include "ui_tela.h"
#include <QtSql>
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>
#include "funcionarionovo.h"
#include "alterardados.h"
#include "ui_alterardados.h"
#include <QRegularExpression>
#include <QTextStream>

tela::tela(QWidget *parent)
    : QDialog(parent), ui(new Ui::tela)
{
    ui->setupUi(this);

    // Caminho do banco de dados
    QString dbPath = "C:/BancoDados/cadastroFuncionarios/CadastroFuncionarios.db";

    // Verificar se o arquivo do banco de dados existe
    if (!QFile::exists(dbPath)) {
        QMessageBox::critical(this, "Erro", "Arquivo do banco de dados não encontrado!");
        return;
    }

    // Conectar ao banco de dados
    QSqlDatabase db;
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        db = QSqlDatabase::database("qt_sql_default_connection");
    } else {
        db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName(dbPath);
    }

    if (!db.open()) {
        QMessageBox::critical(this, "Erro", "Não foi possível abrir o banco de dados!");
        qDebug() << "Erro ao abrir o banco de dados:" << db.lastError().text();
        return;
    }

    qDebug() << "Banco de dados conectado. Caminho:" << db.databaseName();

    // Verificar se a tabela existe ou criar se necessário
    QSqlQuery createTableQuery;
    QString createTableSQL = "CREATE TABLE IF NOT EXISTS funcionarios ("
                             "IDF INTEGER PRIMARY KEY AUTOINCREMENT, "
                             "CPF TEXT, "
                             "NomeFuncionario TEXT, "
                             "SalarioFuncionario REAL, "
                             "DepartamentoFuncionario TEXT, "
                             "DataNascimentoFuncionario TEXT, "
                             "TelefoneFuncionario TEXT, "
                             "EmailFuncionario TEXT)";
    if (!createTableQuery.exec(createTableSQL)) {
        qDebug() << "Erro ao criar tabela funcionarios:" << createTableQuery.lastError().text();
        return;
    } else {
        qDebug() << "Tabela funcionarios criada ou já existe.";
    }

    // Configurar cabeçalhos da tabela
    QStringList cabecalhos = {
        "ID",
        "CPF",
        "NOME",
        "SALÁRIO",
        "DEPARTAMENTO",
        "DATA NASCIMENTO",
        "TELEFONE",
        "EMAIL"
    };

    ui->tableWidget->setColumnCount(cabecalhos.size());
    ui->tableWidget->setHorizontalHeaderLabels(cabecalhos);

    // Estilo dos componentes
    ui->lineEdit->setPlaceholderText("Digite algo para pesquisar");
    ui->lineEdit->setStyleSheet("color: black; background-color: yellow; selection-color: black; selection-background-color: yellow;");
    QString estiloBotoes = "color: white; background-color: green; border-style: outset; border-width: 2px; "
                           "border-radius: 10px; border-color: beige; font: bold 14px;";
    ui->pushButton->setStyleSheet(estiloBotoes);
    ui->pushButton_2->setStyleSheet(estiloBotoes);

    // Carregar dados na tabela
    carregardados();
}

// Destrutor
tela::~tela()
{
    delete ui;
}


void tela::carregardados()
{
    // Adicionar os títulos das colunas na ComboBox
    ui->comboBox->addItem("IDF");
    ui->comboBox->addItem("CPF");
    ui->comboBox->addItem("NomeFuncionario");
    ui->comboBox->addItem("SalarioFuncionario");
    ui->comboBox->addItem("DepartamentoFuncionario");
    ui->comboBox->addItem("DataNascimentoFuncionario");
    ui->comboBox->addItem("TelefoneFuncionario");
    ui->comboBox->addItem("EmailFuncionario");

    // Resto do código para carregar os dados na tabela
    QSqlQuery query;
    QString sql = "SELECT IDF, CPF, NomeFuncionario, SalarioFuncionario, "
                  "DepartamentoFuncionario, DataNascimentoFuncionario, "
                  "TelefoneFuncionario, EmailFuncionario FROM funcionarios";

    if (!query.exec(sql)) {
        qDebug() << "Erro ao executar a consulta SQL:" << query.lastError().text();
        QMessageBox::critical(this, "Erro", "Erro ao carregar dados: " + query.lastError().text());
        return;
    }

    ui->tableWidget->setRowCount(0);
    int linha = 0;
    double somaSalarios = 0.0;

    while (query.next()) {
        ui->tableWidget->insertRow(linha);
        for (int coluna = 0; coluna < 8; ++coluna) {
            QString value = query.value(coluna).toString();
            ui->tableWidget->setItem(linha, coluna, new QTableWidgetItem(value));
        }
        somaSalarios += query.value(3).toDouble(); // Soma os salários, que estão na coluna 3
        linha++;
    }

    ui->tableWidget->verticalHeader()->setVisible(false);
    ui->tableWidget->resizeColumnsToContents();
    ui->tableWidget->resizeRowsToContents();
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);

    // Atualizar a label_4 com o total de registros
    QSqlQuery countQuery;
    countQuery.exec("SELECT COUNT(*) FROM funcionarios");

    if (countQuery.next()) {
        int totalRegistros = countQuery.value(0).toInt();
        ui->label_4->setText("Total de Funcionários: " + QString::number(totalRegistros));
    }

    // Atualizar a label_3 com a soma dos salários
    ui->label_3->setText("Total de Salários: R$ " + QString::number(somaSalarios, 'f', 2));
}


void tela::on_lineEdit_textChanged(const QString &)
{
    QString textopesquisa = ui->lineEdit->text();
    QString colunaSelecionada = ui->comboBox->currentText();  // Obtém o nome da coluna selecionada
    QString pesquisa;

    // Criar a consulta SQL baseada na coluna selecionada
    pesquisa = "SELECT IDF, CPF, NomeFuncionario, SalarioFuncionario, DepartamentoFuncionario, "
               "DataNascimentoFuncionario, TelefoneFuncionario, EmailFuncionario "
               "FROM funcionarios WHERE " + colunaSelecionada + " LIKE '%" + textopesquisa + "%'";

    QSqlQuery query;
    if (!query.exec(pesquisa)) {
        qDebug() << "Erro ao executar consulta:" << query.lastError().text();
        return;
    }

    // Atualizar a tabela
    ui->tableWidget->clearContents();
    ui->tableWidget->setRowCount(0);
    int linha = 0;
    double somaSalarios = 0.0;

    while (query.next()) {
        ui->tableWidget->insertRow(linha);
        for (int coluna = 0; coluna < 8; ++coluna) {
            ui->tableWidget->setItem(linha, coluna, new QTableWidgetItem(query.value(coluna).toString()));
        }
        somaSalarios += query.value(3).toDouble(); // Soma os salários, que estão na coluna 3
        linha++;
    }

    if (linha == 0 && !textopesquisa.isEmpty()) {
        QMessageBox::information(this, "Aviso", "Nenhum dado encontrado para o filtro atual.");
    }

    // Atualizar a label_4 com o total de registros após a pesquisa
    QSqlQuery countQuery;
    countQuery.exec(pesquisa);  // Usando a mesma consulta de pesquisa para contar os registros

    if (countQuery.next()) {
        int totalRegistros = countQuery.value(0).toInt();
        ui->label_4->setText("Total de Funcionários: " + QString::number(totalRegistros));
    }

    // Atualizar a label_3 com a soma dos salários após a pesquisa
    ui->label_3->setText("Total de Salários: R$ " + QString::number(somaSalarios, 'f', 2));
}

void tela::on_pushButton_clicked()
{
    funcionarionovo abreformulariodecadastro;
    abreformulariodecadastro.exec();
    carregardados();
}

void tela::on_pushButton_2_clicked()
{
    int linhaatual = ui->tableWidget->currentRow();
    if (linhaatual < 0) {
        QMessageBox::warning(this, "Aviso", "Selecione um funcionário para excluir.");
        return;
    }

    QString idselecionado = ui->tableWidget->item(linhaatual, 0)->text();

    // Confirmar exclusão
    QMessageBox::StandardButton reply = QMessageBox::question(this, "Confirmação",
                                                              "Você tem certeza que deseja excluir este funcionário?",
                                                              QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        QSqlQuery query;
        query.prepare("DELETE FROM funcionarios WHERE IDF = ?");
        query.addBindValue(idselecionado);
        if (query.exec()) {
            ui->tableWidget->removeRow(linhaatual);
            QMessageBox::information(this, "Atenção", "Funcionário excluído com sucesso.");
        } else {
            QMessageBox::information(this, "Atenção", "Erro ao excluir o funcionário.");
        }
    }
}
void tela::on_pushButton_3_clicked()
{
    // Usando QFileDialog para escolher o caminho e nome do arquivo
    QString fileName = QFileDialog::getSaveFileName(this, "Salvar como", "", "CSV Files (*.csv)");

    if (fileName.isEmpty()) {
        return; // Se o usuário cancelar a escolha do arquivo, retorna
    }

    // Criando um arquivo para escrever os dados no formato CSV
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Erro", "Não foi possível abrir o arquivo.");
        return;
    }

    // Escrever no arquivo CSV usando QTextStream
    QTextStream out(&file);

    // Cabeçalho
    for (int col = 0; col < ui->tableWidget->columnCount(); col++) {
        out << ui->tableWidget->horizontalHeaderItem(col)->text();
        if (col < ui->tableWidget->columnCount() - 1) out << ","; // Separador de colunas
    }
    out << "\n"; // Quebra de linha após o cabeçalho

    // Dados das linhas
    for (int row = 0; row < ui->tableWidget->rowCount(); row++) {
        for (int col = 0; col < ui->tableWidget->columnCount(); col++) {
            out << ui->tableWidget->item(row, col)->text();
            if (col < ui->tableWidget->columnCount() - 1) out << ","; // Separador de colunas
        }
        out << "\n"; // Quebra de linha após cada linha de dados
    }

    // Fechar o arquivo após a escrita
    file.close();

    QMessageBox::information(this, "Sucesso", "Dados exportados para CSV com sucesso.");
}





void tela::on_tableWidget_cellDoubleClicked(int row, int column)
{
    (void)column;  // Ignora a coluna

    QString id = ui->tableWidget->item(row, 0)->text();
    QString cpf = ui->tableWidget->item(row, 1)->text();
    QString nome = ui->tableWidget->item(row, 2)->text();
    // Remover o símbolo de moeda para conversão
    double salario = ui->tableWidget->item(row, 3)->text()
                         .remove(QRegularExpression("[^\\d,.]"))
                         .replace(",", ".")
                         .toDouble();
    QString departamento = ui->tableWidget->item(row, 4)->text();
    QString nascimento = ui->tableWidget->item(row, 5)->text();
    QString telefone = ui->tableWidget->item(row, 6)->text();
    QString email = ui->tableWidget->item(row, 7)->text();

    alterardados janelaAlteracao(this);
    janelaAlteracao.setDados(id, cpf, nome, salario, departamento, nascimento, telefone, email);

    if (janelaAlteracao.exec() == QDialog::Accepted) {
        carregardados();  // Recarregar a tabela com os dados atualizados
    }
}

