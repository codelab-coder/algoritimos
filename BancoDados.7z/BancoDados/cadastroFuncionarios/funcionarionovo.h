#ifndef FUNCIONARIONOVO_H
#define FUNCIONARIONOVO_H

#include <QDialog>

namespace Ui {
class funcionarionovo;
}

class funcionarionovo : public QDialog
{
    Q_OBJECT

public:
    explicit funcionarionovo(QWidget *parent = nullptr);
    ~funcionarionovo();

private slots:
    void on_pushButton_clicked();

    void on_lineEdit_3_editingFinished();

private:
    Ui::funcionarionovo *ui;
};

#endif // FUNCIONARIONOVO_H
