#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_actionsair_triggered();

    void on_actioncopiar_triggered();

    void on_actioncolar_triggered();

    void on_actionrecortar_triggered();

    void on_actionfonte_triggered();

    void on_actioncor_triggered();

    void on_actionfundo_triggered();

    void on_actionsobre_triggered();

    void on_actionsalvar_como_triggered();

    void on_actionabrir_triggered();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
