#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFontDialog>
#include<QColor>
#include<QMessageBox>
#include<QFileDialog>
#include<QTextStream>
#include<QFile>
#include<QColorDialog>
#include<QPalette>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setCentralWidget(ui->txttexto);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionsair_triggered()
{


    close();
}


void MainWindow::on_actioncopiar_triggered()
{
    ui->txttexto->copy();
}


void MainWindow::on_actioncolar_triggered()
{
    ui->txttexto->paste();
}


void MainWindow::on_actionrecortar_triggered()
{
        ui->txttexto->cut();
}


void MainWindow::on_actionfonte_triggered()
{


    bool confirmar;
    QFont fonte;
    fonte=QFontDialog::getFont(&confirmar,this);

    if(!confirmar){
        return;
    }else{
        ui->txttexto->setFont(fonte);
    }

}


void MainWindow::on_actioncor_triggered()
{


    QColor corescolhida;
    corescolhida=QColorDialog::getColor(Qt::white, this);
    ui->txttexto->setTextColor(corescolhida);
}


void MainWindow::on_actionfundo_triggered()
{
    QPalette paletacores;
    QColor corescolhida=QColorDialog::getColor(Qt::white, this);
    paletacores.setColor(QPalette::Base,corescolhida);
    if(corescolhida.isValid()){
        ui->txttexto->setPalette(paletacores);
    }else{
        return;
    }

}






void MainWindow::on_actionsobre_triggered()
{
    QString mensagem;
    mensagem="curso lógica de programação\n";
    mensagem+="curso C++\n";
    mensagem+="curso QT\n";
    mensagem+="curso python\n";
    mensagem+="Estude muito\n";
    QMessageBox::about(this,"sobre", mensagem);
}





void MainWindow::on_actionsalvar_como_triggered()
{


    QFile arquivo;
    QTextStream caminho;
    QString nomedoarquivo;
    nomedoarquivo=QFileDialog::getSaveFileName(this, "selecione onde quer salvar");

    if(nomedoarquivo.isEmpty()){
        return;
    }else{
        arquivo.setFileName(nomedoarquivo);
        arquivo.open(QIODevice::WriteOnly|QIODevice::Text);
    }
    if(arquivo.isOpen()){

    }   else{
        QMessageBox::critical(this,"aviso", "erro ao salvar o caminho");

    }
caminho.setDevice(&arquivo);
    caminho<<ui->txttexto->toPlainText();
arquivo.close();
}


void MainWindow::on_actionabrir_triggered()
{

    QFile arquivo;
    QTextStream caminho;
    QString nomedoarquivo;
    nomedoarquivo=QFileDialog::getOpenFileName(this, "selecione o arquivo");

    if(nomedoarquivo.isEmpty()){
        return;
    }else{
        arquivo.setFileName(nomedoarquivo);
        arquivo.open(QIODevice::ReadOnly|QIODevice::Text);
    }
    if(arquivo.isOpen()){

    }   else{
        QMessageBox::critical(this,"aviso", "erro ao abrir o caminho");

        return;

    }
    caminho.setDevice(&arquivo);
    ui->txttexto->setPlainText(caminho.readAll());
    arquivo.flush();
}



