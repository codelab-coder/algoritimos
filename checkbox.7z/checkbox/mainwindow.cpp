#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QMessageBox"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_teste_clicked()
{


    if(ui->checkGostoporviagens->isChecked()){
        QMessageBox::information(this, "mensagem","você gosta de viajar");
    }else{
        QMessageBox::information(this, "mensagem","você não gosta de viajar");
    }
}





void MainWindow::on_pushbutton_clicked()
{

    QString Mensagem;
    bool letraA,letraB,letraC;
    letraA=ui->l1->isChecked();
    letraB=ui->l2->isChecked();
    letraC=ui->l3->isChecked();
    if(letraA==true &&letraB==false && letraC==false ){
        Mensagem="letraA está marcada";
    }else if(letraA==true &&letraB==true && letraC==false ){
        Mensagem="letraA e letraB estão marcadas";
    }else if(letraA==true &&letraB==true && letraC==true ){
        Mensagem="letraA, letraB e letraC estão marcadas";
    }else     if(letraA==false &&letraB==true &&letraC==false ){
        Mensagem="letraB está marcada";
    }else if(letraA==true &&letraB==true && letraC==false ){
        Mensagem="letraB e letraA estão marcadas";
    }else if(letraA==false && letraB==true&&letraC==true){
        Mensagem="letraB e letrac estão marcadas";
    }else if(letraA==false &&letraB==false && letraC==true ){
        Mensagem="letraC está marcada";
    }else if(letraA==true && letraB==false&& letraC==true){
        Mensagem="letraC e letraA estão marcadas";
    }else if(letraA==false &&letraB==true && letraC==true ){
        Mensagem="letraC e letraB estão marcadas";
    }else if(letraA==false &&letraB==false && letraC==false ){
        Mensagem="nehuma letra foi selecionada";
    }
    QMessageBox::information(this, "opção", Mensagem);
}



