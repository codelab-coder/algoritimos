#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QInputDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_inputbutton_clicked()
{
    QString nome=QInputDialog::getText(this, "mensagem", "digite o seu nome");
    ui->aluno->setText(nome);

    int idade=QInputDialog::getInt(this, "mensagem", "digite sua idade");
    ui->idade->setText(QString::number(idade));
}


void MainWindow::on_media_clicked()
{
    double nota1=QInputDialog::getDouble(this, "mensagem", "digite sua nota 1");
    ui->idade->setText(QString::number(nota1));

    double nota2=QInputDialog::getDouble(this, "mensagem", "digite sua nota 2");
    ui->idade->setText(QString::number(nota2));

    double media=(nota1+nota2)/2;
    ui->notaf->setText(QString::number(media));
}


void MainWindow::on_inputdialogmultline_clicked()
{

    QString frase =QInputDialog::getMultiLineText(this,"mensagem","digite a frase");
    ui->frase->setText(frase);

}



void MainWindow::on_cor_2_clicked()
{
    QStringList cores;
    cores<<"amarelo";
    cores<<"verde";
    cores<<"azul";
    cores<<"vermelho";
    QString corselecionada=QInputDialog::getItem(this, "escolha","clique em uma cor para selecionar", cores);
    ui->cor->setText(corselecionada);
}

