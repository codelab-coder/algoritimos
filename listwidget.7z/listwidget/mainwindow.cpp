#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

QVector<int> listitems; // Vetor para armazenar os índices selecionados.

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_add_clicked()
{
    // Adiciona um novo item ao widget de lista.
    if (!ui->lineEdit->text().isEmpty()) { // Verifica se o texto não está vazio.
        ui->listitems->addItem(ui->lineEdit->text());
        ui->lineEdit->clear();
        ui->lineEdit->setFocus();
    }
}

void MainWindow::on_listitems_currentRowChanged(int currentRow)
{
    if (currentRow < 0 || !ui->listitems->currentItem()) {
        return; // Proteção contra índices inválidos.
    }

    // Verifica se o índice já está no vetor.
    if (!listitems.contains(currentRow)) {
        listitems.push_back(currentRow);
        ui->listitems->currentItem()->setBackground(Qt::white);
        ui->listitems->currentItem()->setForeground(Qt::black);
    } else {
        listitems.removeOne(currentRow); // Remove o índice do vetor.
        ui->listitems->currentItem()->setBackground(Qt::white);
        ui->listitems->currentItem()->setForeground(Qt::black);
    }

    qDebug() << "Itens selecionados:" << listitems;
}


